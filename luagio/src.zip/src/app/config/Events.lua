
--[[--
   facade 能够处理 三类事件
   ---- 命名方式  moduleName_proxy(view)_methodName ，第一个模块名必须保证
]]

Login_LoginProxy_Login = "Login_LoginProxy_Login"
