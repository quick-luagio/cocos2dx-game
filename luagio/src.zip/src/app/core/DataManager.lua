--[[--

数据缓存中心

]]
DataManager = {}