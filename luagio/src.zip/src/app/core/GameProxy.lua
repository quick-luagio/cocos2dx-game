--[[--
游戏数据代理类
允许向控制层发送消息
1、处理后端请求
2、处理数据转换和缓存
]]
local GameProxy = class("GameProxy",Proxy)


return GameProxy