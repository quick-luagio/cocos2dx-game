--[[--

静态数据缓存中心

]]

StaticDataManager = {}


